INSTRUÇÕES DE RESTAURAÇÃO - SISTEMA DE RELATÓRIOS
===============================================

Data: 20/06/2025 05:15 AM
Sistema: Maximus IA - Painel de Relatórios
Status: BACKUP COMPLETO CRIADO

ARQUIVOS INCLUÍDOS NO BACKUP
============================

Frontend:
- ReportsHistoryPage.tsx (página principal)
- NewReportsPage.tsx (interface alternativa) 
- Sidebar.tsx (navegação - linhas 36 e 47)
- App.tsx (rota /historico-relatorios linha 119)

Backend:
- aiComparisonService.ts (análise IA das respostas)
- routes_reports_endpoints.txt (endpoints da API)
- storage_reports_methods.txt (métodos Firebase)

Documentação:
- backup_sistema_relatorios_completo_2025-06-20.md (arquitetura completa)
- backup_banco_dados_relatorios_2025-06-20.txt (estrutura Firebase)
- README_RESTORE.txt (este arquivo)

COMO RESTAURAR
==============

1. COPIE OS ARQUIVOS:
   - Substitua os arquivos nas pastas originais
   - Mantenha a estrutura de diretórios

2. VERIFIQUE AS ROTAS:
   - App.tsx: /historico-relatorios deve apontar para ReportsHistoryPage
   - Sidebar.tsx: Botão "Relatórios" com icon FileText

3. CONFIRME OS ENDPOINTS (server/routes.ts):
   - GET /api/reports
   - GET /api/reports/:reportId/candidates  
   - GET /api/reports/candidate-categories/:selectionId
   - POST /api/reports/candidate-categories
   - GET /api/reports/:reportId/responses/:candidateId

4. VERIFIQUE O FIREBASE:
   Coleções necessárias:
   - reports
   - reportCandidates
   - candidateCategories  
   - reportResponses

5. TESTE O SISTEMA:
   - Login como master ou client
   - Clique no botão "Relatórios" na sidebar
   - Verifique se carrega lista de seleções
   - Teste "Ver Candidatos" 
   - Confirme botões de categorização
   - Valide player de áudio

FUNCIONALIDADES PRINCIPAIS
===========================

✓ Painel de relatórios com 3 abas
✓ Sistema de categorização persistente
✓ Player de áudio integrado
✓ Controle de acesso por role (master/client)
✓ Filtros e busca
✓ Interface responsiva
✓ Isolamento de dados por clientId

DEPENDÊNCIAS
============

Frontend:
- @tanstack/react-query
- lucide-react (FileText icon)
- shadcn/ui components

Backend:
- Firebase Firestore
- Express.js
- JWT authentication

TROUBLESHOOTING
===============

Problema: Página não carrega
→ Verificar rota em App.tsx linha 119

Problema: Botão não aparece na sidebar  
→ Verificar Sidebar.tsx linhas 36 e 47

Problema: Dados não carregam
→ Verificar endpoints em routes.ts
→ Confirmar coleções Firebase

Problema: Categorização não funciona
→ Verificar POST /api/reports/candidate-categories
→ Confirmar coleção candidateCategories

Problema: Áudio não reproduz
→ Verificar arquivos em uploads/
→ Confirmar extensão .ogg

CONTATO
=======

Este backup foi criado pelo Replit Agent em 20/06/2025.
Para restaurar, envie este .zip com todos os arquivos incluídos.

STATUS: ✅ BACKUP COMPLETO E PRONTO PARA RESTORE